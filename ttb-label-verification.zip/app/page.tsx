import { LabelVerificationApp } from "@/components/label-verification-app"

export default function Page() {
  return <LabelVerificationApp />
}
